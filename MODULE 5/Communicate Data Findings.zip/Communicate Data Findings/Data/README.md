# Data and License

The Data can be downloaded <a href= https://www.fordgobike.com/system-data>here.</a>

**License:** <a href = https://assets.fordgobike.com/data-license-agreement.html>Ford GoBike Data License Agreement</a>

You can also run "gather_goBike_data.py" to request the data.
